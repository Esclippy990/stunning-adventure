exports.settings = {
  CHAT_HISTORY_SAVE: false,
};
